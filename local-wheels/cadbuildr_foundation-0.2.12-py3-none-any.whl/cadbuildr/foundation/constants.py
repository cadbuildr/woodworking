"""Constants for foundation schema."""

import re
from typing import Sequence, Union

# Color mapping from old foundation
DEFAULT_COLORS: dict[str, list[float]] = {
    "red": [1, 0, 0],
    "green": [0, 1, 0],
    "blue": [0, 0, 1],
    "yellow": [1, 1, 0],
    "cyan": [0, 1, 1],
    "magenta": [1, 0, 1],
    "black": [0, 0, 0],
    "white": [1, 1, 1],
    "grey": [0.5, 0.5, 0.5],
    "orange": [1, 0.5, 0],
    "purple": [0.5, 0, 0.5],
    "brown": [0.5, 0.25, 0],
    "pink": [1, 0.75, 0.8],
    "light_blue": [0.68, 0.85, 0.9],
    "light_green": [0.56, 0.93, 0.56],
    "dark_green": [0, 0.39, 0],
    "dark_grey": [0.25, 0.25, 0.25],
    "light_grey": [0.75, 0.75, 0.75],
    "dark_red": [0.5, 0, 0],
    "dark_blue": [0, 0, 0.5],
    "dark_yellow": [0.5, 0.5, 0],
    "dark_cyan": [0, 0.5, 0.5],
    "dark_magenta": [0.5, 0, 0.5],
    "dark_orange": [1, 0.5, 0],
    "dark_purple": [0.5, 0, 0.5],
    "dark_brown": [0.25, 0.12, 0],
    "dark_pink": [1, 0.75, 0.8],
    "beige": [0.96, 0.96, 0.86],
    "plywood": [0.73, 0.54, 0.38],
    # LEGO-inspired palette names (approximate sRGB in [0,1])
    "bright_red": [0.79, 0.10, 0.13],
    "bright_orange": [0.91, 0.39, 0.12],
    "bright_yellow": [0.98, 0.82, 0.07],
    "bright_green": [0.29, 0.62, 0.29],
    "bright_blue": [0.00, 0.34, 0.65],
    "medium_azure": [0.31, 0.76, 0.93],
    "lavender": [0.67, 0.54, 0.73],
    "coral": [1.00, 0.49, 0.47],
    "light_bluish_gray": [0.63, 0.66, 0.67],
    "dark_bluish_gray": [0.42, 0.45, 0.48],
    "tan": [0.84, 0.77, 0.60],
    "dark_tan": [0.67, 0.57, 0.42],
    "reddish_brown": [0.41, 0.24, 0.17],
    "nougat": [0.80, 0.56, 0.41],
    "lime": [0.73, 0.91, 0.27],
    "sand_green": [0.63, 0.75, 0.67],
    "dark_turquoise": [0.00, 0.56, 0.61],
    "olive_green": [0.43, 0.48, 0.26],
}

# A color spec is either a name / hex string, or an (r, g, b) sequence.
ColorSpec = Union[str, Sequence[float]]

_HEX_RE = re.compile(r"^#?(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def _hex_to_rgb(value: str) -> list[float]:
    """Convert ``#rrggbb`` / ``#rgb`` (with or without ``#``) to ``[r, g, b]`` in [0, 1]."""
    h = value.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    return [int(h[i : i + 2], 16) / 255.0 for i in (0, 2, 4)]


def resolve_color(color: ColorSpec) -> list[float]:
    """Resolve a color spec to an ``[r, g, b]`` list of floats in ``[0, 1]``.

    Accepts:

    * a named color from :data:`DEFAULT_COLORS` (e.g. ``"orange"``), case-insensitive;
    * a hex string — ``"#212121"``, ``"212121"``, or shorthand ``"#abc"``;
    * an RGB sequence of three numbers, given either as floats in ``[0, 1]`` or
      as integers in ``[0, 255]`` (auto-detected when any component is > 1).

    Raises :class:`ValueError` with the list of valid names for unrecognized input.
    """
    if isinstance(color, str):
        name = color.strip()
        # Named colors take precedence over hex parsing.
        if name.lower() in DEFAULT_COLORS:
            return list(DEFAULT_COLORS[name.lower()])
        if _HEX_RE.match(name):
            return _hex_to_rgb(name)
        raise ValueError(
            f"Unknown color {color!r}. Pass a named color (one of "
            f"{list(DEFAULT_COLORS.keys())}), a hex string like '#212121', "
            f"or an [r, g, b] list."
        )

    try:
        components = [float(c) for c in color]
    except (TypeError, ValueError):
        raise ValueError(
            f"Invalid color {color!r}. Expected a named color, a hex string "
            f"like '#212121', or an [r, g, b] sequence."
        )
    if len(components) != 3:
        raise ValueError("RGB color must have exactly 3 components")
    # Auto-detect the 0-255 range and normalize to 0-1.
    if any(c > 1.0 for c in components):
        components = [c / 255.0 for c in components]
    return [min(1.0, max(0.0, c)) for c in components]

# Valid types for DAG serialization
DEFAULT_VALID_TYPES: list[str] = [
    "Part",
    "Assembly",
    "Extrusion",
    "Sketch",
    "Point",
    "Plane",
    "Frame",
    "Line",
    "FloatParameter",
    "IntParameter",
    "BoolParameter",
    "StringParameter",
    "SketchOrigin",
    "PartRoot",
    "AssemblyRoot",
    "Circle",
    "Rectangle",
    "Square",
    "Polygon",
    "Hole",
    "Material",
    "Ellipse",
    "Lathe",
    "Axis",
    "Hexagon",
    "Fillet",
    "Chamfer",
    "Loft",
    "Shell",
    "CustomClosedShape",
    "Arc",
    "EllipseArc",
    "Spline",
    "SVGShape",
    "Helix3D",
    "Sweep",
    "Point3D",
    "FixedTranslationConstraint",
    "InterfaceGridSpec",
    "AssemblyInterface",
    "Sphere",
    "Mirror",
    "BoundingBox",
    "Scale",
    "Offset2D",
    "Bezier",
    "BSpline",
    "Wedge",
    "Section",
    "Split",
    "Project",
    "Text",
    "Draft",
    "FullRound",
    # Type ids are positional: ONLY append below, never insert or remove —
    # existing serialized DAGs depend on the indices above staying stable.
    "Anchor",
    "JointLimits",
    "RigidJoint",
    "RevoluteJoint",
    "SliderJoint",
    "CylindricalJoint",
    "PlanarJoint",
    "BallJoint",
    "PinSlotJoint",
    "ScrewJoint",
    "PartModifier",
    "Connection",
]

DEFAULT_TYPE_REGISTRY: dict[str, int] = {
    type_name: i for i, type_name in enumerate(DEFAULT_VALID_TYPES)
}

# Plane configurations: maps plane name to (xDir, normal) vectors
PLANES_CONFIG: dict[str, tuple[list[int], list[int]]] = {
    "xy": ([1, 0, 0], [0, 0, 1]),
    "yx": ([0, 1, 0], [0, 0, -1]),
    "xz": ([1, 0, 0], [0, -1, 0]),
    "zx": ([0, 0, 1], [0, 1, 0]),
    "yz": ([0, 1, 0], [1, 0, 0]),
    "zy": ([0, 0, 1], [-1, 0, 0]),
}
